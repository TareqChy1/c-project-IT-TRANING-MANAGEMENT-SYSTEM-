﻿namespace ITDbConnection
{
    partial class ManageCourse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageCourse));
            this.InsertbunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.coursedataGridView1 = new System.Windows.Forms.DataGridView();
            this.CourseNamelabel1 = new System.Windows.Forms.Label();
            this.CourseFeelabel2 = new System.Windows.Forms.Label();
            this.Durationlabel3 = new System.Windows.Forms.Label();
            this.CourseNametextBox2 = new System.Windows.Forms.TextBox();
            this.CourseFeetextBox3 = new System.Windows.Forms.TextBox();
            this.DurationtextBox4 = new System.Windows.Forms.TextBox();
            this.UpdatebunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.BackbunifuThinButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.LogOutbunifuThinButton23 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.ExitButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.ResetbunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.deletebunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            ((System.ComponentModel.ISupportInitialize)(this.coursedataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // InsertbunifuThinButton21
            // 
            this.InsertbunifuThinButton21.ActiveBorderThickness = 1;
            this.InsertbunifuThinButton21.ActiveCornerRadius = 20;
            this.InsertbunifuThinButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.InsertbunifuThinButton21.ActiveForecolor = System.Drawing.Color.White;
            this.InsertbunifuThinButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.InsertbunifuThinButton21.BackColor = System.Drawing.Color.Transparent;
            this.InsertbunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("InsertbunifuThinButton21.BackgroundImage")));
            this.InsertbunifuThinButton21.ButtonText = "Insert";
            this.InsertbunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.InsertbunifuThinButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsertbunifuThinButton21.ForeColor = System.Drawing.Color.White;
            this.InsertbunifuThinButton21.IdleBorderThickness = 1;
            this.InsertbunifuThinButton21.IdleCornerRadius = 20;
            this.InsertbunifuThinButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.InsertbunifuThinButton21.IdleForecolor = System.Drawing.Color.White;
            this.InsertbunifuThinButton21.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.InsertbunifuThinButton21.Location = new System.Drawing.Point(14, 331);
            this.InsertbunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.InsertbunifuThinButton21.Name = "InsertbunifuThinButton21";
            this.InsertbunifuThinButton21.Size = new System.Drawing.Size(158, 39);
            this.InsertbunifuThinButton21.TabIndex = 1;
            this.InsertbunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.InsertbunifuThinButton21.Click += new System.EventHandler(this.InsertbunifuThinButton21_Click);
            // 
            // coursedataGridView1
            // 
            this.coursedataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.coursedataGridView1.Location = new System.Drawing.Point(326, 48);
            this.coursedataGridView1.Name = "coursedataGridView1";
            this.coursedataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.coursedataGridView1.Size = new System.Drawing.Size(312, 196);
            this.coursedataGridView1.TabIndex = 2;
            this.coursedataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.coursedataGridView1_CellClick);
            // 
            // CourseNamelabel1
            // 
            this.CourseNamelabel1.AutoSize = true;
            this.CourseNamelabel1.BackColor = System.Drawing.Color.Transparent;
            this.CourseNamelabel1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseNamelabel1.ForeColor = System.Drawing.Color.White;
            this.CourseNamelabel1.Location = new System.Drawing.Point(31, 119);
            this.CourseNamelabel1.Name = "CourseNamelabel1";
            this.CourseNamelabel1.Size = new System.Drawing.Size(106, 19);
            this.CourseNamelabel1.TabIndex = 4;
            this.CourseNamelabel1.Text = "Course Name:";
            // 
            // CourseFeelabel2
            // 
            this.CourseFeelabel2.AutoSize = true;
            this.CourseFeelabel2.BackColor = System.Drawing.Color.Transparent;
            this.CourseFeelabel2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseFeelabel2.ForeColor = System.Drawing.Color.White;
            this.CourseFeelabel2.Location = new System.Drawing.Point(31, 168);
            this.CourseFeelabel2.Name = "CourseFeelabel2";
            this.CourseFeelabel2.Size = new System.Drawing.Size(90, 19);
            this.CourseFeelabel2.TabIndex = 5;
            this.CourseFeelabel2.Text = "Course Fee:";
            // 
            // Durationlabel3
            // 
            this.Durationlabel3.AutoSize = true;
            this.Durationlabel3.BackColor = System.Drawing.Color.Transparent;
            this.Durationlabel3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Durationlabel3.ForeColor = System.Drawing.Color.White;
            this.Durationlabel3.Location = new System.Drawing.Point(31, 214);
            this.Durationlabel3.Name = "Durationlabel3";
            this.Durationlabel3.Size = new System.Drawing.Size(75, 19);
            this.Durationlabel3.TabIndex = 6;
            this.Durationlabel3.Text = "Duration:";
            // 
            // CourseNametextBox2
            // 
            this.CourseNametextBox2.Location = new System.Drawing.Point(143, 120);
            this.CourseNametextBox2.Name = "CourseNametextBox2";
            this.CourseNametextBox2.Size = new System.Drawing.Size(177, 20);
            this.CourseNametextBox2.TabIndex = 7;
            // 
            // CourseFeetextBox3
            // 
            this.CourseFeetextBox3.Location = new System.Drawing.Point(143, 168);
            this.CourseFeetextBox3.Name = "CourseFeetextBox3";
            this.CourseFeetextBox3.Size = new System.Drawing.Size(177, 20);
            this.CourseFeetextBox3.TabIndex = 8;
            // 
            // DurationtextBox4
            // 
            this.DurationtextBox4.Location = new System.Drawing.Point(143, 214);
            this.DurationtextBox4.Name = "DurationtextBox4";
            this.DurationtextBox4.Size = new System.Drawing.Size(177, 20);
            this.DurationtextBox4.TabIndex = 9;
            // 
            // UpdatebunifuThinButton21
            // 
            this.UpdatebunifuThinButton21.ActiveBorderThickness = 1;
            this.UpdatebunifuThinButton21.ActiveCornerRadius = 20;
            this.UpdatebunifuThinButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.UpdatebunifuThinButton21.ActiveForecolor = System.Drawing.Color.White;
            this.UpdatebunifuThinButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.UpdatebunifuThinButton21.BackColor = System.Drawing.Color.Transparent;
            this.UpdatebunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("UpdatebunifuThinButton21.BackgroundImage")));
            this.UpdatebunifuThinButton21.ButtonText = "Update";
            this.UpdatebunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UpdatebunifuThinButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdatebunifuThinButton21.ForeColor = System.Drawing.Color.White;
            this.UpdatebunifuThinButton21.IdleBorderThickness = 1;
            this.UpdatebunifuThinButton21.IdleCornerRadius = 20;
            this.UpdatebunifuThinButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.UpdatebunifuThinButton21.IdleForecolor = System.Drawing.Color.White;
            this.UpdatebunifuThinButton21.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.UpdatebunifuThinButton21.Location = new System.Drawing.Point(195, 331);
            this.UpdatebunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.UpdatebunifuThinButton21.Name = "UpdatebunifuThinButton21";
            this.UpdatebunifuThinButton21.Size = new System.Drawing.Size(125, 39);
            this.UpdatebunifuThinButton21.TabIndex = 10;
            this.UpdatebunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.UpdatebunifuThinButton21.Click += new System.EventHandler(this.UpdatebunifuThinButton21_Click);
            // 
            // BackbunifuThinButton22
            // 
            this.BackbunifuThinButton22.ActiveBorderThickness = 1;
            this.BackbunifuThinButton22.ActiveCornerRadius = 20;
            this.BackbunifuThinButton22.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.BackbunifuThinButton22.ActiveForecolor = System.Drawing.Color.White;
            this.BackbunifuThinButton22.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.BackbunifuThinButton22.BackColor = System.Drawing.Color.Transparent;
            this.BackbunifuThinButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BackbunifuThinButton22.BackgroundImage")));
            this.BackbunifuThinButton22.ButtonText = "Back";
            this.BackbunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackbunifuThinButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackbunifuThinButton22.ForeColor = System.Drawing.Color.White;
            this.BackbunifuThinButton22.IdleBorderThickness = 1;
            this.BackbunifuThinButton22.IdleCornerRadius = 20;
            this.BackbunifuThinButton22.IdleFillColor = System.Drawing.Color.Transparent;
            this.BackbunifuThinButton22.IdleForecolor = System.Drawing.Color.White;
            this.BackbunifuThinButton22.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.BackbunifuThinButton22.Location = new System.Drawing.Point(468, 331);
            this.BackbunifuThinButton22.Margin = new System.Windows.Forms.Padding(5);
            this.BackbunifuThinButton22.Name = "BackbunifuThinButton22";
            this.BackbunifuThinButton22.Size = new System.Drawing.Size(158, 39);
            this.BackbunifuThinButton22.TabIndex = 11;
            this.BackbunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BackbunifuThinButton22.Click += new System.EventHandler(this.BackbunifuThinButton22_Click);
            // 
            // LogOutbunifuThinButton23
            // 
            this.LogOutbunifuThinButton23.ActiveBorderThickness = 1;
            this.LogOutbunifuThinButton23.ActiveCornerRadius = 20;
            this.LogOutbunifuThinButton23.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.LogOutbunifuThinButton23.ActiveForecolor = System.Drawing.Color.White;
            this.LogOutbunifuThinButton23.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.LogOutbunifuThinButton23.BackColor = System.Drawing.Color.Transparent;
            this.LogOutbunifuThinButton23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("LogOutbunifuThinButton23.BackgroundImage")));
            this.LogOutbunifuThinButton23.ButtonText = "Log Out";
            this.LogOutbunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogOutbunifuThinButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOutbunifuThinButton23.ForeColor = System.Drawing.Color.White;
            this.LogOutbunifuThinButton23.IdleBorderThickness = 1;
            this.LogOutbunifuThinButton23.IdleCornerRadius = 20;
            this.LogOutbunifuThinButton23.IdleFillColor = System.Drawing.Color.Transparent;
            this.LogOutbunifuThinButton23.IdleForecolor = System.Drawing.Color.White;
            this.LogOutbunifuThinButton23.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.LogOutbunifuThinButton23.Location = new System.Drawing.Point(468, 399);
            this.LogOutbunifuThinButton23.Margin = new System.Windows.Forms.Padding(5);
            this.LogOutbunifuThinButton23.Name = "LogOutbunifuThinButton23";
            this.LogOutbunifuThinButton23.Size = new System.Drawing.Size(158, 39);
            this.LogOutbunifuThinButton23.TabIndex = 12;
            this.LogOutbunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LogOutbunifuThinButton23.Click += new System.EventHandler(this.LogOutbunifuThinButton23_Click);
            // 
            // ExitButton21
            // 
            this.ExitButton21.ActiveBorderThickness = 1;
            this.ExitButton21.ActiveCornerRadius = 20;
            this.ExitButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.ExitButton21.ActiveForecolor = System.Drawing.Color.White;
            this.ExitButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.ExitButton21.BackColor = System.Drawing.Color.Transparent;
            this.ExitButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ExitButton21.BackgroundImage")));
            this.ExitButton21.ButtonText = "Exit";
            this.ExitButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton21.ForeColor = System.Drawing.Color.White;
            this.ExitButton21.IdleBorderThickness = 1;
            this.ExitButton21.IdleCornerRadius = 20;
            this.ExitButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.ExitButton21.IdleForecolor = System.Drawing.Color.White;
            this.ExitButton21.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ExitButton21.Location = new System.Drawing.Point(14, 399);
            this.ExitButton21.Margin = new System.Windows.Forms.Padding(5);
            this.ExitButton21.Name = "ExitButton21";
            this.ExitButton21.Size = new System.Drawing.Size(158, 39);
            this.ExitButton21.TabIndex = 13;
            this.ExitButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ExitButton21.Click += new System.EventHandler(this.ExitButton21_Click);
            // 
            // ResetbunifuThinButton21
            // 
            this.ResetbunifuThinButton21.ActiveBorderThickness = 1;
            this.ResetbunifuThinButton21.ActiveCornerRadius = 20;
            this.ResetbunifuThinButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.ResetbunifuThinButton21.ActiveForecolor = System.Drawing.Color.White;
            this.ResetbunifuThinButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.ResetbunifuThinButton21.BackColor = System.Drawing.Color.Transparent;
            this.ResetbunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ResetbunifuThinButton21.BackgroundImage")));
            this.ResetbunifuThinButton21.ButtonText = "Reset";
            this.ResetbunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ResetbunifuThinButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetbunifuThinButton21.ForeColor = System.Drawing.Color.White;
            this.ResetbunifuThinButton21.IdleBorderThickness = 1;
            this.ResetbunifuThinButton21.IdleCornerRadius = 20;
            this.ResetbunifuThinButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.ResetbunifuThinButton21.IdleForecolor = System.Drawing.Color.White;
            this.ResetbunifuThinButton21.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ResetbunifuThinButton21.Location = new System.Drawing.Point(206, 399);
            this.ResetbunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.ResetbunifuThinButton21.Name = "ResetbunifuThinButton21";
            this.ResetbunifuThinButton21.Size = new System.Drawing.Size(158, 39);
            this.ResetbunifuThinButton21.TabIndex = 14;
            this.ResetbunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ResetbunifuThinButton21.Click += new System.EventHandler(this.ResetbunifuThinButton21_Click);
            // 
            // deletebunifuThinButton21
            // 
            this.deletebunifuThinButton21.ActiveBorderThickness = 1;
            this.deletebunifuThinButton21.ActiveCornerRadius = 20;
            this.deletebunifuThinButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.deletebunifuThinButton21.ActiveForecolor = System.Drawing.Color.White;
            this.deletebunifuThinButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.deletebunifuThinButton21.BackColor = System.Drawing.Color.Transparent;
            this.deletebunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("deletebunifuThinButton21.BackgroundImage")));
            this.deletebunifuThinButton21.ButtonText = "Delete";
            this.deletebunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deletebunifuThinButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletebunifuThinButton21.ForeColor = System.Drawing.Color.White;
            this.deletebunifuThinButton21.IdleBorderThickness = 1;
            this.deletebunifuThinButton21.IdleCornerRadius = 20;
            this.deletebunifuThinButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.deletebunifuThinButton21.IdleForecolor = System.Drawing.Color.White;
            this.deletebunifuThinButton21.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.deletebunifuThinButton21.Location = new System.Drawing.Point(330, 334);
            this.deletebunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.deletebunifuThinButton21.Name = "deletebunifuThinButton21";
            this.deletebunifuThinButton21.Size = new System.Drawing.Size(115, 36);
            this.deletebunifuThinButton21.TabIndex = 15;
            this.deletebunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.deletebunifuThinButton21.Click += new System.EventHandler(this.deletebunifuThinButton21_Click);
            // 
            // ManageCourse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(640, 452);
            this.Controls.Add(this.deletebunifuThinButton21);
            this.Controls.Add(this.ResetbunifuThinButton21);
            this.Controls.Add(this.ExitButton21);
            this.Controls.Add(this.LogOutbunifuThinButton23);
            this.Controls.Add(this.BackbunifuThinButton22);
            this.Controls.Add(this.UpdatebunifuThinButton21);
            this.Controls.Add(this.DurationtextBox4);
            this.Controls.Add(this.CourseFeetextBox3);
            this.Controls.Add(this.CourseNametextBox2);
            this.Controls.Add(this.Durationlabel3);
            this.Controls.Add(this.CourseFeelabel2);
            this.Controls.Add(this.CourseNamelabel1);
            this.Controls.Add(this.coursedataGridView1);
            this.Controls.Add(this.InsertbunifuThinButton21);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageCourse";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ManageCourse";
            this.Load += new System.EventHandler(this.ManageCourse_Load);
            ((System.ComponentModel.ISupportInitialize)(this.coursedataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 InsertbunifuThinButton21;
        private System.Windows.Forms.DataGridView coursedataGridView1;
        private System.Windows.Forms.Label CourseNamelabel1;
        private System.Windows.Forms.Label CourseFeelabel2;
        private System.Windows.Forms.Label Durationlabel3;
        private System.Windows.Forms.TextBox CourseNametextBox2;
        private System.Windows.Forms.TextBox CourseFeetextBox3;
        private System.Windows.Forms.TextBox DurationtextBox4;
        private Bunifu.Framework.UI.BunifuThinButton2 UpdatebunifuThinButton21;
        private Bunifu.Framework.UI.BunifuThinButton2 BackbunifuThinButton22;
        private Bunifu.Framework.UI.BunifuThinButton2 LogOutbunifuThinButton23;
        private Bunifu.Framework.UI.BunifuThinButton2 ExitButton21;
        private Bunifu.Framework.UI.BunifuThinButton2 ResetbunifuThinButton21;
        private Bunifu.Framework.UI.BunifuThinButton2 deletebunifuThinButton21;
    }
}