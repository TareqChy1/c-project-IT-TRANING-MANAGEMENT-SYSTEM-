﻿namespace ITDbConnection
{
    partial class ChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangePassword));
            this.CurrentPasswordlabel1 = new System.Windows.Forms.Label();
            this.CurrentPasswordtextBox1 = new System.Windows.Forms.TextBox();
            this.NewPasswordlabel1 = new System.Windows.Forms.Label();
            this.NewPasswordtextBox2 = new System.Windows.Forms.TextBox();
            this.SubmitButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.BackButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.ExitButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Idlabel1 = new System.Windows.Forms.Label();
            this.IdtextBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // CurrentPasswordlabel1
            // 
            this.CurrentPasswordlabel1.AutoSize = true;
            this.CurrentPasswordlabel1.BackColor = System.Drawing.Color.Transparent;
            this.CurrentPasswordlabel1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentPasswordlabel1.ForeColor = System.Drawing.Color.White;
            this.CurrentPasswordlabel1.Location = new System.Drawing.Point(64, 162);
            this.CurrentPasswordlabel1.Name = "CurrentPasswordlabel1";
            this.CurrentPasswordlabel1.Size = new System.Drawing.Size(139, 19);
            this.CurrentPasswordlabel1.TabIndex = 0;
            this.CurrentPasswordlabel1.Text = "Current Password:";
            // 
            // CurrentPasswordtextBox1
            // 
            this.CurrentPasswordtextBox1.Location = new System.Drawing.Point(226, 163);
            this.CurrentPasswordtextBox1.Name = "CurrentPasswordtextBox1";
            this.CurrentPasswordtextBox1.Size = new System.Drawing.Size(171, 20);
            this.CurrentPasswordtextBox1.TabIndex = 1;
            // 
            // NewPasswordlabel1
            // 
            this.NewPasswordlabel1.AutoSize = true;
            this.NewPasswordlabel1.BackColor = System.Drawing.Color.Transparent;
            this.NewPasswordlabel1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPasswordlabel1.ForeColor = System.Drawing.Color.White;
            this.NewPasswordlabel1.Location = new System.Drawing.Point(64, 214);
            this.NewPasswordlabel1.Name = "NewPasswordlabel1";
            this.NewPasswordlabel1.Size = new System.Drawing.Size(116, 19);
            this.NewPasswordlabel1.TabIndex = 2;
            this.NewPasswordlabel1.Text = "New Password:";
            // 
            // NewPasswordtextBox2
            // 
            this.NewPasswordtextBox2.Location = new System.Drawing.Point(226, 215);
            this.NewPasswordtextBox2.Name = "NewPasswordtextBox2";
            this.NewPasswordtextBox2.Size = new System.Drawing.Size(171, 20);
            this.NewPasswordtextBox2.TabIndex = 3;
            // 
            // SubmitButton21
            // 
            this.SubmitButton21.ActiveBorderThickness = 1;
            this.SubmitButton21.ActiveCornerRadius = 20;
            this.SubmitButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.SubmitButton21.ActiveForecolor = System.Drawing.Color.White;
            this.SubmitButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.SubmitButton21.BackColor = System.Drawing.Color.Transparent;
            this.SubmitButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SubmitButton21.BackgroundImage")));
            this.SubmitButton21.ButtonText = "Submit";
            this.SubmitButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SubmitButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButton21.ForeColor = System.Drawing.Color.SeaGreen;
            this.SubmitButton21.IdleBorderThickness = 1;
            this.SubmitButton21.IdleCornerRadius = 20;
            this.SubmitButton21.IdleFillColor = System.Drawing.Color.Black;
            this.SubmitButton21.IdleForecolor = System.Drawing.Color.White;
            this.SubmitButton21.IdleLineColor = System.Drawing.Color.Violet;
            this.SubmitButton21.Location = new System.Drawing.Point(68, 288);
            this.SubmitButton21.Margin = new System.Windows.Forms.Padding(5);
            this.SubmitButton21.Name = "SubmitButton21";
            this.SubmitButton21.Size = new System.Drawing.Size(135, 39);
            this.SubmitButton21.TabIndex = 4;
            this.SubmitButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.SubmitButton21.Click += new System.EventHandler(this.SubmitButton21_Click);
            // 
            // BackButton22
            // 
            this.BackButton22.ActiveBorderThickness = 1;
            this.BackButton22.ActiveCornerRadius = 20;
            this.BackButton22.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.BackButton22.ActiveForecolor = System.Drawing.Color.White;
            this.BackButton22.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.BackButton22.BackColor = System.Drawing.Color.Transparent;
            this.BackButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BackButton22.BackgroundImage")));
            this.BackButton22.ButtonText = "Back";
            this.BackButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton22.ForeColor = System.Drawing.Color.SeaGreen;
            this.BackButton22.IdleBorderThickness = 1;
            this.BackButton22.IdleCornerRadius = 20;
            this.BackButton22.IdleFillColor = System.Drawing.Color.Black;
            this.BackButton22.IdleForecolor = System.Drawing.Color.White;
            this.BackButton22.IdleLineColor = System.Drawing.Color.Violet;
            this.BackButton22.Location = new System.Drawing.Point(296, 288);
            this.BackButton22.Margin = new System.Windows.Forms.Padding(5);
            this.BackButton22.Name = "BackButton22";
            this.BackButton22.Size = new System.Drawing.Size(150, 39);
            this.BackButton22.TabIndex = 5;
            this.BackButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BackButton22.Click += new System.EventHandler(this.BackButton22_Click);
            // 
            // ExitButton21
            // 
            this.ExitButton21.ActiveBorderThickness = 1;
            this.ExitButton21.ActiveCornerRadius = 20;
            this.ExitButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.ExitButton21.ActiveForecolor = System.Drawing.Color.White;
            this.ExitButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.ExitButton21.BackColor = System.Drawing.Color.Transparent;
            this.ExitButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ExitButton21.BackgroundImage")));
            this.ExitButton21.ButtonText = "Exit";
            this.ExitButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton21.ForeColor = System.Drawing.Color.SeaGreen;
            this.ExitButton21.IdleBorderThickness = 1;
            this.ExitButton21.IdleCornerRadius = 20;
            this.ExitButton21.IdleFillColor = System.Drawing.Color.Black;
            this.ExitButton21.IdleForecolor = System.Drawing.Color.White;
            this.ExitButton21.IdleLineColor = System.Drawing.Color.Violet;
            this.ExitButton21.Location = new System.Drawing.Point(184, 337);
            this.ExitButton21.Margin = new System.Windows.Forms.Padding(5);
            this.ExitButton21.Name = "ExitButton21";
            this.ExitButton21.Size = new System.Drawing.Size(144, 35);
            this.ExitButton21.TabIndex = 6;
            this.ExitButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ExitButton21.Click += new System.EventHandler(this.ExitButton21_Click);
            // 
            // Idlabel1
            // 
            this.Idlabel1.AutoSize = true;
            this.Idlabel1.BackColor = System.Drawing.Color.Transparent;
            this.Idlabel1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Idlabel1.ForeColor = System.Drawing.Color.White;
            this.Idlabel1.Location = new System.Drawing.Point(64, 108);
            this.Idlabel1.Name = "Idlabel1";
            this.Idlabel1.Size = new System.Drawing.Size(29, 19);
            this.Idlabel1.TabIndex = 7;
            this.Idlabel1.Text = "ID:";
            // 
            // IdtextBox1
            // 
            this.IdtextBox1.Location = new System.Drawing.Point(226, 109);
            this.IdtextBox1.Name = "IdtextBox1";
            this.IdtextBox1.Size = new System.Drawing.Size(171, 20);
            this.IdtextBox1.TabIndex = 8;
            this.IdtextBox1.TextChanged += new System.EventHandler(this.IdtextBox1_TextChanged);
            // 
            // ChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(501, 386);
            this.Controls.Add(this.IdtextBox1);
            this.Controls.Add(this.Idlabel1);
            this.Controls.Add(this.ExitButton21);
            this.Controls.Add(this.BackButton22);
            this.Controls.Add(this.SubmitButton21);
            this.Controls.Add(this.NewPasswordtextBox2);
            this.Controls.Add(this.NewPasswordlabel1);
            this.Controls.Add(this.CurrentPasswordtextBox1);
            this.Controls.Add(this.CurrentPasswordlabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChangePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChangePassword";
            this.Load += new System.EventHandler(this.ChangePassword_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CurrentPasswordlabel1;
        private System.Windows.Forms.TextBox CurrentPasswordtextBox1;
        private System.Windows.Forms.Label NewPasswordlabel1;
        private System.Windows.Forms.TextBox NewPasswordtextBox2;
        private Bunifu.Framework.UI.BunifuThinButton2 SubmitButton21;
        private Bunifu.Framework.UI.BunifuThinButton2 BackButton22;
        private Bunifu.Framework.UI.BunifuThinButton2 ExitButton21;
        private System.Windows.Forms.Label Idlabel1;
        private System.Windows.Forms.TextBox IdtextBox1;
    }
}