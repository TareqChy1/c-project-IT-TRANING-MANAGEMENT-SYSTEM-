﻿namespace ITDbConnection
{
    partial class EmployeeChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeChangePassword));
            this.IDlabel1 = new System.Windows.Forms.Label();
            this.IdtextBox1 = new System.Windows.Forms.TextBox();
            this.SubmitButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.CurrentPasswordlabel1 = new System.Windows.Forms.Label();
            this.NewPasswordlabel2 = new System.Windows.Forms.Label();
            this.CurrentPasswordtextBox2 = new System.Windows.Forms.TextBox();
            this.NewPasswordtextBox3 = new System.Windows.Forms.TextBox();
            this.LogOutButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.BackButton23 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.ExitButton24 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.SuspendLayout();
            // 
            // IDlabel1
            // 
            this.IDlabel1.AutoSize = true;
            this.IDlabel1.BackColor = System.Drawing.Color.Transparent;
            this.IDlabel1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IDlabel1.ForeColor = System.Drawing.Color.White;
            this.IDlabel1.Location = new System.Drawing.Point(39, 69);
            this.IDlabel1.Name = "IDlabel1";
            this.IDlabel1.Size = new System.Drawing.Size(29, 19);
            this.IDlabel1.TabIndex = 0;
            this.IDlabel1.Text = "ID:";
            // 
            // IdtextBox1
            // 
            this.IdtextBox1.Location = new System.Drawing.Point(184, 68);
            this.IdtextBox1.Name = "IdtextBox1";
            this.IdtextBox1.Size = new System.Drawing.Size(290, 20);
            this.IdtextBox1.TabIndex = 1;
            // 
            // SubmitButton21
            // 
            this.SubmitButton21.ActiveBorderThickness = 1;
            this.SubmitButton21.ActiveCornerRadius = 20;
            this.SubmitButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.SubmitButton21.ActiveForecolor = System.Drawing.Color.White;
            this.SubmitButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.SubmitButton21.BackColor = System.Drawing.Color.Transparent;
            this.SubmitButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SubmitButton21.BackgroundImage")));
            this.SubmitButton21.ButtonText = "Submit";
            this.SubmitButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SubmitButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButton21.ForeColor = System.Drawing.Color.SeaGreen;
            this.SubmitButton21.IdleBorderThickness = 1;
            this.SubmitButton21.IdleCornerRadius = 20;
            this.SubmitButton21.IdleFillColor = System.Drawing.Color.White;
            this.SubmitButton21.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.SubmitButton21.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.SubmitButton21.Location = new System.Drawing.Point(4, 275);
            this.SubmitButton21.Margin = new System.Windows.Forms.Padding(5);
            this.SubmitButton21.Name = "SubmitButton21";
            this.SubmitButton21.Size = new System.Drawing.Size(118, 31);
            this.SubmitButton21.TabIndex = 2;
            this.SubmitButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.SubmitButton21.Click += new System.EventHandler(this.SubmitButton21_Click);
            // 
            // CurrentPasswordlabel1
            // 
            this.CurrentPasswordlabel1.AutoSize = true;
            this.CurrentPasswordlabel1.BackColor = System.Drawing.Color.Transparent;
            this.CurrentPasswordlabel1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentPasswordlabel1.ForeColor = System.Drawing.Color.White;
            this.CurrentPasswordlabel1.Location = new System.Drawing.Point(39, 149);
            this.CurrentPasswordlabel1.Name = "CurrentPasswordlabel1";
            this.CurrentPasswordlabel1.Size = new System.Drawing.Size(139, 19);
            this.CurrentPasswordlabel1.TabIndex = 3;
            this.CurrentPasswordlabel1.Text = "Current Password:";
            // 
            // NewPasswordlabel2
            // 
            this.NewPasswordlabel2.AutoSize = true;
            this.NewPasswordlabel2.BackColor = System.Drawing.Color.Transparent;
            this.NewPasswordlabel2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPasswordlabel2.ForeColor = System.Drawing.Color.White;
            this.NewPasswordlabel2.Location = new System.Drawing.Point(39, 217);
            this.NewPasswordlabel2.Name = "NewPasswordlabel2";
            this.NewPasswordlabel2.Size = new System.Drawing.Size(116, 19);
            this.NewPasswordlabel2.TabIndex = 4;
            this.NewPasswordlabel2.Text = "New Password:";
            // 
            // CurrentPasswordtextBox2
            // 
            this.CurrentPasswordtextBox2.Location = new System.Drawing.Point(184, 148);
            this.CurrentPasswordtextBox2.Name = "CurrentPasswordtextBox2";
            this.CurrentPasswordtextBox2.Size = new System.Drawing.Size(290, 20);
            this.CurrentPasswordtextBox2.TabIndex = 5;
            // 
            // NewPasswordtextBox3
            // 
            this.NewPasswordtextBox3.Location = new System.Drawing.Point(184, 218);
            this.NewPasswordtextBox3.Name = "NewPasswordtextBox3";
            this.NewPasswordtextBox3.Size = new System.Drawing.Size(290, 20);
            this.NewPasswordtextBox3.TabIndex = 6;
            // 
            // LogOutButton22
            // 
            this.LogOutButton22.ActiveBorderThickness = 1;
            this.LogOutButton22.ActiveCornerRadius = 20;
            this.LogOutButton22.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.LogOutButton22.ActiveForecolor = System.Drawing.Color.White;
            this.LogOutButton22.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.LogOutButton22.BackColor = System.Drawing.Color.Transparent;
            this.LogOutButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("LogOutButton22.BackgroundImage")));
            this.LogOutButton22.ButtonText = "Log Out ";
            this.LogOutButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogOutButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOutButton22.ForeColor = System.Drawing.Color.SeaGreen;
            this.LogOutButton22.IdleBorderThickness = 1;
            this.LogOutButton22.IdleCornerRadius = 20;
            this.LogOutButton22.IdleFillColor = System.Drawing.Color.White;
            this.LogOutButton22.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.LogOutButton22.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.LogOutButton22.Location = new System.Drawing.Point(184, 275);
            this.LogOutButton22.Margin = new System.Windows.Forms.Padding(5);
            this.LogOutButton22.Name = "LogOutButton22";
            this.LogOutButton22.Size = new System.Drawing.Size(109, 31);
            this.LogOutButton22.TabIndex = 7;
            this.LogOutButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LogOutButton22.Click += new System.EventHandler(this.LogOutButton22_Click);
            // 
            // BackButton23
            // 
            this.BackButton23.ActiveBorderThickness = 1;
            this.BackButton23.ActiveCornerRadius = 20;
            this.BackButton23.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.BackButton23.ActiveForecolor = System.Drawing.Color.White;
            this.BackButton23.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.BackButton23.BackColor = System.Drawing.Color.Transparent;
            this.BackButton23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BackButton23.BackgroundImage")));
            this.BackButton23.ButtonText = "Back";
            this.BackButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton23.ForeColor = System.Drawing.Color.SeaGreen;
            this.BackButton23.IdleBorderThickness = 1;
            this.BackButton23.IdleCornerRadius = 20;
            this.BackButton23.IdleFillColor = System.Drawing.Color.White;
            this.BackButton23.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.BackButton23.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.BackButton23.Location = new System.Drawing.Point(365, 275);
            this.BackButton23.Margin = new System.Windows.Forms.Padding(5);
            this.BackButton23.Name = "BackButton23";
            this.BackButton23.Size = new System.Drawing.Size(109, 37);
            this.BackButton23.TabIndex = 8;
            this.BackButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BackButton23.Click += new System.EventHandler(this.BackButton23_Click);
            // 
            // ExitButton24
            // 
            this.ExitButton24.ActiveBorderThickness = 1;
            this.ExitButton24.ActiveCornerRadius = 20;
            this.ExitButton24.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.ExitButton24.ActiveForecolor = System.Drawing.Color.White;
            this.ExitButton24.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.ExitButton24.BackColor = System.Drawing.Color.Transparent;
            this.ExitButton24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ExitButton24.BackgroundImage")));
            this.ExitButton24.ButtonText = "Exit";
            this.ExitButton24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitButton24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton24.ForeColor = System.Drawing.Color.SeaGreen;
            this.ExitButton24.IdleBorderThickness = 1;
            this.ExitButton24.IdleCornerRadius = 20;
            this.ExitButton24.IdleFillColor = System.Drawing.Color.White;
            this.ExitButton24.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.ExitButton24.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.ExitButton24.Location = new System.Drawing.Point(365, 322);
            this.ExitButton24.Margin = new System.Windows.Forms.Padding(5);
            this.ExitButton24.Name = "ExitButton24";
            this.ExitButton24.Size = new System.Drawing.Size(109, 31);
            this.ExitButton24.TabIndex = 9;
            this.ExitButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ExitButton24.Click += new System.EventHandler(this.ExitButton24_Click);
            // 
            // EmployeeChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(500, 367);
            this.Controls.Add(this.ExitButton24);
            this.Controls.Add(this.BackButton23);
            this.Controls.Add(this.LogOutButton22);
            this.Controls.Add(this.NewPasswordtextBox3);
            this.Controls.Add(this.CurrentPasswordtextBox2);
            this.Controls.Add(this.NewPasswordlabel2);
            this.Controls.Add(this.CurrentPasswordlabel1);
            this.Controls.Add(this.SubmitButton21);
            this.Controls.Add(this.IdtextBox1);
            this.Controls.Add(this.IDlabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EmployeeChangePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EmployeeChangePassword";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label IDlabel1;
        private System.Windows.Forms.TextBox IdtextBox1;
        private Bunifu.Framework.UI.BunifuThinButton2 SubmitButton21;
        private System.Windows.Forms.Label CurrentPasswordlabel1;
        private System.Windows.Forms.Label NewPasswordlabel2;
        private System.Windows.Forms.TextBox CurrentPasswordtextBox2;
        private System.Windows.Forms.TextBox NewPasswordtextBox3;
        private Bunifu.Framework.UI.BunifuThinButton2 LogOutButton22;
        private Bunifu.Framework.UI.BunifuThinButton2 BackButton23;
        private Bunifu.Framework.UI.BunifuThinButton2 ExitButton24;
    }
}