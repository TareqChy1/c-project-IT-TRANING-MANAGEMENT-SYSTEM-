﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ITDbConnection
{
    class LoginData
    {
        internal void InsertUser(IT.Entities.User u)
        {
            throw new NotImplementedException();
        }
    }
}
