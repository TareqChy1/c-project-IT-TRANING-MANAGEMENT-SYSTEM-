﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITDbConnection
{
    public partial class AddManager : Form
    {
        public AddManager()
        {
            InitializeComponent();
        }

        
    }
}
