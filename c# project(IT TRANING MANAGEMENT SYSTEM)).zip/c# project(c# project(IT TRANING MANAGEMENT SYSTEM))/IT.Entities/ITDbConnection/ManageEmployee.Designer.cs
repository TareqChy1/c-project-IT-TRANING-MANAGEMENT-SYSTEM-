﻿namespace ITDbConnection
{
    partial class ManageEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageEmployee));
            this.Namelabel1 = new System.Windows.Forms.Label();
            this.InserbunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.EmployeeRecorddataGridView1 = new System.Windows.Forms.DataGridView();
            this.Statuslabel2 = new System.Windows.Forms.Label();
            this.NametextBox1 = new System.Windows.Forms.TextBox();
            this.RefreshbunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.LogOutbunifuThinButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.BackbunifuThinButton23 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.ExitButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Emaillabel1 = new System.Windows.Forms.Label();
            this.PasswordtextBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.StatusradioButton1 = new System.Windows.Forms.RadioButton();
            this.ActiveStatusradioButton2 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Idlabel2 = new System.Windows.Forms.Label();
            this.IdtextBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeRecorddataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Namelabel1
            // 
            this.Namelabel1.AutoSize = true;
            this.Namelabel1.BackColor = System.Drawing.Color.Transparent;
            this.Namelabel1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel1.ForeColor = System.Drawing.Color.White;
            this.Namelabel1.Location = new System.Drawing.Point(50, 80);
            this.Namelabel1.Name = "Namelabel1";
            this.Namelabel1.Size = new System.Drawing.Size(53, 19);
            this.Namelabel1.TabIndex = 0;
            this.Namelabel1.Text = "Name:";
            // 
            // InserbunifuThinButton21
            // 
            this.InserbunifuThinButton21.ActiveBorderThickness = 1;
            this.InserbunifuThinButton21.ActiveCornerRadius = 20;
            this.InserbunifuThinButton21.ActiveFillColor = System.Drawing.Color.White;
            this.InserbunifuThinButton21.ActiveForecolor = System.Drawing.Color.Transparent;
            this.InserbunifuThinButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.InserbunifuThinButton21.BackColor = System.Drawing.SystemColors.Control;
            this.InserbunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("InserbunifuThinButton21.BackgroundImage")));
            this.InserbunifuThinButton21.ButtonText = "Insert";
            this.InserbunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.InserbunifuThinButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InserbunifuThinButton21.ForeColor = System.Drawing.Color.White;
            this.InserbunifuThinButton21.IdleBorderThickness = 1;
            this.InserbunifuThinButton21.IdleCornerRadius = 20;
            this.InserbunifuThinButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.InserbunifuThinButton21.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.InserbunifuThinButton21.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.InserbunifuThinButton21.Location = new System.Drawing.Point(14, 288);
            this.InserbunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.InserbunifuThinButton21.Name = "InserbunifuThinButton21";
            this.InserbunifuThinButton21.Size = new System.Drawing.Size(106, 31);
            this.InserbunifuThinButton21.TabIndex = 2;
            this.InserbunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.InserbunifuThinButton21.Click += new System.EventHandler(this.InserbunifuThinButton21_Click);
            // 
            // EmployeeRecorddataGridView1
            // 
            this.EmployeeRecorddataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EmployeeRecorddataGridView1.Location = new System.Drawing.Point(312, 34);
            this.EmployeeRecorddataGridView1.Name = "EmployeeRecorddataGridView1";
            this.EmployeeRecorddataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.EmployeeRecorddataGridView1.Size = new System.Drawing.Size(289, 215);
            this.EmployeeRecorddataGridView1.TabIndex = 3;
            this.EmployeeRecorddataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.EmployeeRecorddataGridView1_CellClick);
            // 
            // Statuslabel2
            // 
            this.Statuslabel2.AutoSize = true;
            this.Statuslabel2.BackColor = System.Drawing.Color.Transparent;
            this.Statuslabel2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Statuslabel2.ForeColor = System.Drawing.Color.White;
            this.Statuslabel2.Location = new System.Drawing.Point(50, 121);
            this.Statuslabel2.Name = "Statuslabel2";
            this.Statuslabel2.Size = new System.Drawing.Size(55, 19);
            this.Statuslabel2.TabIndex = 6;
            this.Statuslabel2.Text = "Status:";
            // 
            // NametextBox1
            // 
            this.NametextBox1.Location = new System.Drawing.Point(134, 81);
            this.NametextBox1.Name = "NametextBox1";
            this.NametextBox1.Size = new System.Drawing.Size(169, 20);
            this.NametextBox1.TabIndex = 9;
            // 
            // RefreshbunifuThinButton21
            // 
            this.RefreshbunifuThinButton21.ActiveBorderThickness = 1;
            this.RefreshbunifuThinButton21.ActiveCornerRadius = 20;
            this.RefreshbunifuThinButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.RefreshbunifuThinButton21.ActiveForecolor = System.Drawing.Color.Transparent;
            this.RefreshbunifuThinButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.RefreshbunifuThinButton21.BackColor = System.Drawing.SystemColors.Control;
            this.RefreshbunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("RefreshbunifuThinButton21.BackgroundImage")));
            this.RefreshbunifuThinButton21.ButtonText = "Refresh";
            this.RefreshbunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RefreshbunifuThinButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RefreshbunifuThinButton21.ForeColor = System.Drawing.Color.White;
            this.RefreshbunifuThinButton21.IdleBorderThickness = 1;
            this.RefreshbunifuThinButton21.IdleCornerRadius = 20;
            this.RefreshbunifuThinButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.RefreshbunifuThinButton21.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.RefreshbunifuThinButton21.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.RefreshbunifuThinButton21.Location = new System.Drawing.Point(160, 288);
            this.RefreshbunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.RefreshbunifuThinButton21.Name = "RefreshbunifuThinButton21";
            this.RefreshbunifuThinButton21.Size = new System.Drawing.Size(106, 31);
            this.RefreshbunifuThinButton21.TabIndex = 14;
            this.RefreshbunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RefreshbunifuThinButton21.Click += new System.EventHandler(this.RefreshbunifuThinButton21_Click);
            // 
            // LogOutbunifuThinButton22
            // 
            this.LogOutbunifuThinButton22.ActiveBorderThickness = 1;
            this.LogOutbunifuThinButton22.ActiveCornerRadius = 20;
            this.LogOutbunifuThinButton22.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.LogOutbunifuThinButton22.ActiveForecolor = System.Drawing.Color.Transparent;
            this.LogOutbunifuThinButton22.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.LogOutbunifuThinButton22.BackColor = System.Drawing.SystemColors.Control;
            this.LogOutbunifuThinButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("LogOutbunifuThinButton22.BackgroundImage")));
            this.LogOutbunifuThinButton22.ButtonText = "Log Out";
            this.LogOutbunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogOutbunifuThinButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOutbunifuThinButton22.ForeColor = System.Drawing.Color.White;
            this.LogOutbunifuThinButton22.IdleBorderThickness = 1;
            this.LogOutbunifuThinButton22.IdleCornerRadius = 20;
            this.LogOutbunifuThinButton22.IdleFillColor = System.Drawing.Color.Transparent;
            this.LogOutbunifuThinButton22.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.LogOutbunifuThinButton22.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.LogOutbunifuThinButton22.Location = new System.Drawing.Point(312, 288);
            this.LogOutbunifuThinButton22.Margin = new System.Windows.Forms.Padding(5);
            this.LogOutbunifuThinButton22.Name = "LogOutbunifuThinButton22";
            this.LogOutbunifuThinButton22.Size = new System.Drawing.Size(106, 31);
            this.LogOutbunifuThinButton22.TabIndex = 15;
            this.LogOutbunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LogOutbunifuThinButton22.Click += new System.EventHandler(this.LogOutbunifuThinButton22_Click);
            // 
            // BackbunifuThinButton23
            // 
            this.BackbunifuThinButton23.ActiveBorderThickness = 1;
            this.BackbunifuThinButton23.ActiveCornerRadius = 20;
            this.BackbunifuThinButton23.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.BackbunifuThinButton23.ActiveForecolor = System.Drawing.Color.Transparent;
            this.BackbunifuThinButton23.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.BackbunifuThinButton23.BackColor = System.Drawing.SystemColors.Control;
            this.BackbunifuThinButton23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BackbunifuThinButton23.BackgroundImage")));
            this.BackbunifuThinButton23.ButtonText = "Back";
            this.BackbunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackbunifuThinButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackbunifuThinButton23.ForeColor = System.Drawing.Color.White;
            this.BackbunifuThinButton23.IdleBorderThickness = 1;
            this.BackbunifuThinButton23.IdleCornerRadius = 20;
            this.BackbunifuThinButton23.IdleFillColor = System.Drawing.Color.Transparent;
            this.BackbunifuThinButton23.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.BackbunifuThinButton23.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.BackbunifuThinButton23.Location = new System.Drawing.Point(493, 288);
            this.BackbunifuThinButton23.Margin = new System.Windows.Forms.Padding(5);
            this.BackbunifuThinButton23.Name = "BackbunifuThinButton23";
            this.BackbunifuThinButton23.Size = new System.Drawing.Size(106, 31);
            this.BackbunifuThinButton23.TabIndex = 16;
            this.BackbunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BackbunifuThinButton23.Click += new System.EventHandler(this.BackbunifuThinButton23_Click);
            // 
            // ExitButton21
            // 
            this.ExitButton21.ActiveBorderThickness = 1;
            this.ExitButton21.ActiveCornerRadius = 20;
            this.ExitButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.ExitButton21.ActiveForecolor = System.Drawing.Color.Transparent;
            this.ExitButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.ExitButton21.BackColor = System.Drawing.SystemColors.Control;
            this.ExitButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ExitButton21.BackgroundImage")));
            this.ExitButton21.ButtonText = "Exit";
            this.ExitButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton21.ForeColor = System.Drawing.Color.White;
            this.ExitButton21.IdleBorderThickness = 1;
            this.ExitButton21.IdleCornerRadius = 20;
            this.ExitButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.ExitButton21.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.ExitButton21.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.ExitButton21.Location = new System.Drawing.Point(493, 329);
            this.ExitButton21.Margin = new System.Windows.Forms.Padding(5);
            this.ExitButton21.Name = "ExitButton21";
            this.ExitButton21.Size = new System.Drawing.Size(106, 27);
            this.ExitButton21.TabIndex = 17;
            this.ExitButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ExitButton21.Click += new System.EventHandler(this.ExitButton21_Click);
            // 
            // Emaillabel1
            // 
            this.Emaillabel1.AutoSize = true;
            this.Emaillabel1.BackColor = System.Drawing.Color.Transparent;
            this.Emaillabel1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel1.ForeColor = System.Drawing.Color.White;
            this.Emaillabel1.Location = new System.Drawing.Point(47, 159);
            this.Emaillabel1.Name = "Emaillabel1";
            this.Emaillabel1.Size = new System.Drawing.Size(81, 19);
            this.Emaillabel1.TabIndex = 18;
            this.Emaillabel1.Text = "Password:";
            // 
            // PasswordtextBox1
            // 
            this.PasswordtextBox1.Location = new System.Drawing.Point(134, 160);
            this.PasswordtextBox1.Name = "PasswordtextBox1";
            this.PasswordtextBox1.Size = new System.Drawing.Size(169, 20);
            this.PasswordtextBox1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 19);
            this.label1.TabIndex = 22;
            this.label1.Text = "Active Status:";
            // 
            // StatusradioButton1
            // 
            this.StatusradioButton1.AutoSize = true;
            this.StatusradioButton1.Location = new System.Drawing.Point(160, 121);
            this.StatusradioButton1.Name = "StatusradioButton1";
            this.StatusradioButton1.Size = new System.Drawing.Size(31, 17);
            this.StatusradioButton1.TabIndex = 23;
            this.StatusradioButton1.TabStop = true;
            this.StatusradioButton1.Text = "3";
            this.StatusradioButton1.UseVisualStyleBackColor = true;
            // 
            // ActiveStatusradioButton2
            // 
            this.ActiveStatusradioButton2.AutoSize = true;
            this.ActiveStatusradioButton2.ForeColor = System.Drawing.Color.White;
            this.ActiveStatusradioButton2.Location = new System.Drawing.Point(138, 16);
            this.ActiveStatusradioButton2.Name = "ActiveStatusradioButton2";
            this.ActiveStatusradioButton2.Size = new System.Drawing.Size(55, 17);
            this.ActiveStatusradioButton2.TabIndex = 24;
            this.ActiveStatusradioButton2.TabStop = true;
            this.ActiveStatusradioButton2.Text = "Active";
            this.ActiveStatusradioButton2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.ActiveStatusradioButton2);
            this.groupBox1.Location = new System.Drawing.Point(54, 200);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(252, 49);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            // 
            // Idlabel2
            // 
            this.Idlabel2.AutoSize = true;
            this.Idlabel2.BackColor = System.Drawing.Color.Transparent;
            this.Idlabel2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Idlabel2.ForeColor = System.Drawing.Color.White;
            this.Idlabel2.Location = new System.Drawing.Point(50, 34);
            this.Idlabel2.Name = "Idlabel2";
            this.Idlabel2.Size = new System.Drawing.Size(27, 19);
            this.Idlabel2.TabIndex = 28;
            this.Idlabel2.Text = "Id:";
            // 
            // IdtextBox1
            // 
            this.IdtextBox1.Location = new System.Drawing.Point(134, 33);
            this.IdtextBox1.Name = "IdtextBox1";
            this.IdtextBox1.Size = new System.Drawing.Size(169, 20);
            this.IdtextBox1.TabIndex = 29;
            // 
            // ManageEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(613, 370);
            this.Controls.Add(this.IdtextBox1);
            this.Controls.Add(this.Idlabel2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.StatusradioButton1);
            this.Controls.Add(this.PasswordtextBox1);
            this.Controls.Add(this.Emaillabel1);
            this.Controls.Add(this.ExitButton21);
            this.Controls.Add(this.BackbunifuThinButton23);
            this.Controls.Add(this.LogOutbunifuThinButton22);
            this.Controls.Add(this.RefreshbunifuThinButton21);
            this.Controls.Add(this.NametextBox1);
            this.Controls.Add(this.Statuslabel2);
            this.Controls.Add(this.EmployeeRecorddataGridView1);
            this.Controls.Add(this.InserbunifuThinButton21);
            this.Controls.Add(this.Namelabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ManageEmployee";
            this.Load += new System.EventHandler(this.ManageEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeRecorddataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Namelabel1;
        private Bunifu.Framework.UI.BunifuThinButton2 InserbunifuThinButton21;
        private System.Windows.Forms.DataGridView EmployeeRecorddataGridView1;
        private System.Windows.Forms.Label Statuslabel2;
        private System.Windows.Forms.TextBox NametextBox1;
        private Bunifu.Framework.UI.BunifuThinButton2 RefreshbunifuThinButton21;
        private Bunifu.Framework.UI.BunifuThinButton2 LogOutbunifuThinButton22;
        private Bunifu.Framework.UI.BunifuThinButton2 BackbunifuThinButton23;
        private Bunifu.Framework.UI.BunifuThinButton2 ExitButton21;
        private System.Windows.Forms.Label Emaillabel1;
        private System.Windows.Forms.TextBox PasswordtextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton StatusradioButton1;
        private System.Windows.Forms.RadioButton ActiveStatusradioButton2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label Idlabel2;
        private System.Windows.Forms.TextBox IdtextBox1;
    }
}