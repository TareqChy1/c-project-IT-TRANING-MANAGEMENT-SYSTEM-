﻿namespace ITDbConnection
{
    partial class loginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(loginForm));
            this.loginButton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.ExitButton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.ShowAllCourseButton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Passwordlabel = new System.Windows.Forms.Label();
            this.UserIdlabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.UserIDtextBox = new System.Windows.Forms.TextBox();
            this.PasswordtextBox = new System.Windows.Forms.TextBox();
            this.ShowcheckBox1 = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // loginButton
            // 
            this.loginButton.ActiveBorderThickness = 1;
            this.loginButton.ActiveCornerRadius = 20;
            this.loginButton.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.loginButton.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.loginButton.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.loginButton.BackColor = System.Drawing.Color.White;
            this.loginButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("loginButton.BackgroundImage")));
            this.loginButton.ButtonText = "Login ";
            this.loginButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginButton.ForeColor = System.Drawing.Color.SeaGreen;
            this.loginButton.IdleBorderThickness = 1;
            this.loginButton.IdleCornerRadius = 20;
            this.loginButton.IdleFillColor = System.Drawing.Color.Empty;
            this.loginButton.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.loginButton.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.loginButton.Location = new System.Drawing.Point(93, 301);
            this.loginButton.Margin = new System.Windows.Forms.Padding(5);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(140, 39);
            this.loginButton.TabIndex = 2;
            this.loginButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.ActiveBorderThickness = 1;
            this.ExitButton.ActiveCornerRadius = 20;
            this.ExitButton.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.ExitButton.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.ExitButton.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.ExitButton.BackColor = System.Drawing.Color.White;
            this.ExitButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ExitButton.BackgroundImage")));
            this.ExitButton.ButtonText = "Exit";
            this.ExitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.ForeColor = System.Drawing.Color.SeaGreen;
            this.ExitButton.IdleBorderThickness = 1;
            this.ExitButton.IdleCornerRadius = 20;
            this.ExitButton.IdleFillColor = System.Drawing.Color.Empty;
            this.ExitButton.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ExitButton.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.ExitButton.Location = new System.Drawing.Point(85, 389);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(5);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(158, 40);
            this.ExitButton.TabIndex = 6;
            this.ExitButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ShowAllCourseButton
            // 
            this.ShowAllCourseButton.ActiveBorderThickness = 1;
            this.ShowAllCourseButton.ActiveCornerRadius = 20;
            this.ShowAllCourseButton.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.ShowAllCourseButton.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.ShowAllCourseButton.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.ShowAllCourseButton.BackColor = System.Drawing.Color.White;
            this.ShowAllCourseButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ShowAllCourseButton.BackgroundImage")));
            this.ShowAllCourseButton.ButtonText = "Show All Course";
            this.ShowAllCourseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowAllCourseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowAllCourseButton.ForeColor = System.Drawing.Color.SeaGreen;
            this.ShowAllCourseButton.IdleBorderThickness = 1;
            this.ShowAllCourseButton.IdleCornerRadius = 20;
            this.ShowAllCourseButton.IdleFillColor = System.Drawing.Color.Empty;
            this.ShowAllCourseButton.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ShowAllCourseButton.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(41)))), ((int)(((byte)(91)))));
            this.ShowAllCourseButton.Location = new System.Drawing.Point(85, 344);
            this.ShowAllCourseButton.Margin = new System.Windows.Forms.Padding(5);
            this.ShowAllCourseButton.Name = "ShowAllCourseButton";
            this.ShowAllCourseButton.Size = new System.Drawing.Size(158, 39);
            this.ShowAllCourseButton.TabIndex = 4;
            this.ShowAllCourseButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ShowAllCourseButton.Click += new System.EventHandler(this.ShowAllCourseButton_Click);
            // 
            // Passwordlabel
            // 
            this.Passwordlabel.AutoSize = true;
            this.Passwordlabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Passwordlabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Passwordlabel.Location = new System.Drawing.Point(13, 196);
            this.Passwordlabel.Name = "Passwordlabel";
            this.Passwordlabel.Size = new System.Drawing.Size(81, 19);
            this.Passwordlabel.TabIndex = 8;
            this.Passwordlabel.Text = "Password";
            // 
            // UserIdlabel
            // 
            this.UserIdlabel.AutoSize = true;
            this.UserIdlabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIdlabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.UserIdlabel.Location = new System.Drawing.Point(13, 132);
            this.UserIdlabel.Name = "UserIdlabel";
            this.UserIdlabel.Size = new System.Drawing.Size(63, 19);
            this.UserIdlabel.TabIndex = 7;
            this.UserIdlabel.Text = "User ID";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(109, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // UserIDtextBox
            // 
            this.UserIDtextBox.Location = new System.Drawing.Point(22, 164);
            this.UserIDtextBox.Multiline = true;
            this.UserIDtextBox.Name = "UserIDtextBox";
            this.UserIDtextBox.Size = new System.Drawing.Size(201, 20);
            this.UserIDtextBox.TabIndex = 12;
            this.UserIDtextBox.TextChanged += new System.EventHandler(this.UserIDtextBox_TextChanged);
            // 
            // PasswordtextBox
            // 
            this.PasswordtextBox.Location = new System.Drawing.Point(22, 225);
            this.PasswordtextBox.Multiline = true;
            this.PasswordtextBox.Name = "PasswordtextBox";
            this.PasswordtextBox.PasswordChar = '*';
            this.PasswordtextBox.Size = new System.Drawing.Size(201, 19);
            this.PasswordtextBox.TabIndex = 13;
            this.PasswordtextBox.TextChanged += new System.EventHandler(this.PasswordtextBox_TextChanged);
            // 
            // ShowcheckBox1
            // 
            this.ShowcheckBox1.AutoSize = true;
            this.ShowcheckBox1.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowcheckBox1.Location = new System.Drawing.Point(250, 226);
            this.ShowcheckBox1.Name = "ShowcheckBox1";
            this.ShowcheckBox1.Size = new System.Drawing.Size(56, 19);
            this.ShowcheckBox1.TabIndex = 14;
            this.ShowcheckBox1.Text = "Show";
            this.ShowcheckBox1.UseVisualStyleBackColor = true;
            this.ShowcheckBox1.CheckedChanged += new System.EventHandler(this.ShowcheckBox1_CheckedChanged);
            // 
            // loginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(348, 506);
            this.Controls.Add(this.ShowcheckBox1);
            this.Controls.Add(this.PasswordtextBox);
            this.Controls.Add(this.UserIDtextBox);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.UserIdlabel);
            this.Controls.Add(this.Passwordlabel);
            this.Controls.Add(this.ShowAllCourseButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.loginButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "loginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "loginFrom";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 loginButton;
        private Bunifu.Framework.UI.BunifuThinButton2 ExitButton;
        private Bunifu.Framework.UI.BunifuThinButton2 ShowAllCourseButton;
        private System.Windows.Forms.Label Passwordlabel;
        private System.Windows.Forms.Label UserIdlabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox UserIDtextBox;
        private System.Windows.Forms.TextBox PasswordtextBox;
        private System.Windows.Forms.CheckBox ShowcheckBox1;
    }
}