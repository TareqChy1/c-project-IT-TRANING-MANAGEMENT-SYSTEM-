﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace IT.Entities
{
    public class Employeecs
    {
        
        public string EmployeeName { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Designation { get; set; }
        public float Salary { get; set; }
        public string Gender { get; set; }
        public  int Phone { get; set; }
        public int Age { get; set; }
        public string Status { get; set; }
        public string ActiveStatus { get; set; }
    }
}
